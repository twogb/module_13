package org.example.task_1;

public class Task2 {
}
